//
//  Completion_Record+CoreDataClass.swift
//  HabitTracker
//
//  Created by Bryan Hoang on 5/8/23.
//
//

import Foundation
import CoreData


public class Completion_Record: NSManagedObject {

}
