//
//  Record+CoreDataClass.swift
//  HabitTracker
//
//  Created by Bryan Hoang on 5/3/23.
//
//

import Foundation
import CoreData


public class Record: NSManagedObject {

}
